/* Register new vehicle init functions here - (see hunterInit below and fn_hunterInit.sqf) */

class LVR
{
    class vehInitFncs
    {
        file = "LVR\functions";
		class vehRespawn      	  {}; //main respawn function - Do Not Delete
		class hunterInit          {}; // Example - Can Be Deleted 
		class medicsupplycrate          {}; 
		class acemedicsupplycrate          {};
		class contener          {};
		class little          {};
		class truckmedic          {};
		class truckammo          {};
		class truckclear          {};
//		class mhqcontener          {};
		class cargoammo          {};
		class vheammo          {};
		class helienemie          {};
		class vehenemie          {};
		class uav          {};



    };
};