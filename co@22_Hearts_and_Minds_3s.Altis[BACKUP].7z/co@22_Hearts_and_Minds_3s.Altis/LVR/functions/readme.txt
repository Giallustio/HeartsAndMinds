Create as many fn_ files (functions) here as you like and register them into the functions.hpp for vehicle init usage (OPTIONAL) 
See the usage comment atop fn_vehrespawn.sqf for more info.

