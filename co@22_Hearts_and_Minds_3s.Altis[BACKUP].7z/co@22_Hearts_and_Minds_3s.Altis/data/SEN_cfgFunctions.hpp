// =========================================================================================================
// Transport SEN add by Vdauphin
// =========================================================================================================
class SEN {
	tag = "SEN";
	class core {
		file = "fnc";
		class getNearPlayers;
		class findRandomPos;
		class spawnGroup;
		class settingsPre {preInit = 1;};
		class settingsPost {postInit = 1;};
		class transportRequest;
		class transportResponse;
		class transportHandler;
		class transportDisabled;
	};
};