// credits - Bohemia Interactive
class SEN_transportAcknowledged {
	name = "";
	sound[] = {"media\transport_acknowledged.ogg", 2, 1};
	titles[] = {};
};
class SEN_transportWelcome {
	name = "";
	sound[] = {"media\transport_welcome.ogg", 4.5, 1};
	titles[] = {};
};
class SEN_transportAccomplished {
	name = "";
	sound[] = {"media\transport_accomplished.ogg", 4.5, 1};
	titles[] = {};
};
class SEN_transportDestroyed {
	name = "";
	sound[] = {"media\cas_heli_destroyed.ogg", 2, 1};
	titles[] = {};
};